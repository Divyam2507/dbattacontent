package com.cg.jpaquerydemo.dao;

import java.util.List;

import com.cg.jpaquerydemo.model.Book;

public interface bookDao {
	Book addBook(Book book);
	Book updateBook(Book book);
	Book getBookByAuthor(String author);
	Book getBookByCode(Integer code);
	List<Book> getAllBook();

}
