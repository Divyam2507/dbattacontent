package com.cg.jpaquerydemo.service;

import java.util.List;

import javax.persistence.EntityTransaction;

import com.cg.jpaquerydemo.dao.bookDao;
import com.cg.jpaquerydemo.dao.bookDaoImpl;
import com.cg.jpaquerydemo.model.Book;
import com.cg.jpaquerydemo.util.JPAUtil;

public class bookServiceImpl implements bookService{
	private bookDao bookdao;
	
	public bookServiceImpl(bookDao bookdao) {
		bookdao = new bookDaoImpl();
	}

	@Override
	public Book addBook(Book book) {
		EntityTransaction txn =JPAUtil.getTransaction();
		txn.begin();
		Book savedBook = bookdao.addBook(book);
		txn.commit();
		return savedBook;
		
	}

	@Override
	public Book updateBook(Book book) {
		EntityTransaction txn =JPAUtil.getTransaction();
		txn.begin();
		Book updateBook = bookdao.updateBook(book);
		txn.commit();
		return updateBook;
	}

	@Override
	public Book getBookByAuthor(String author) {
		return null;
	}

	@Override
	public Book getBookByCode(Integer code) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Book> getAllBook() {
		// TODO Auto-generated method stub
		return null;
	}
	

}
