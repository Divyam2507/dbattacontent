package com.cg.jpaquerydemo.dao;

import java.util.List;


import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import com.cg.jpaquerydemo.model.Book;
import com.cg.jpaquerydemo.util.JPAUtil;

public class bookDaoImpl implements bookDao {
	private EntityManager entityManager;
	
	public bookDaoImpl() {
		entityManager = JPAUtil.getEntityManger();
	}

	@Override
	public Book addBook(Book book) {
		entityManager.getTransaction().begin();
		entityManager.persist(book);
		entityManager.getTransaction().commit();
		return book;
	}

	@Override
	public Book updateBook(Book book) {
		entityManager.getTransaction().begin();
		entityManager.getTransaction().commit();
		return entityManager.merge(book);
	}

	@Override
	public Book getBookByAuthor(String author) {
		TypedQuery<Book> typedQuery= (TypedQuery<Book>) entityManager.createNamedQuery("get_by_author_name");
		typedQuery.setParameter("author", author);
		List<Book> resultList = (List<Book>) typedQuery.getResultList();
		for (Book book : resultList) {
			System.out.println(book.getTitle()+" "+ book.getCode());
			
		}
		return null;
	}

	@Override
	public Book getBookByCode(Integer code) {
		TypedQuery<Book> typedQuery= (TypedQuery<Book>) entityManager.createNamedQuery("get_by_code");
		typedQuery.setParameter("code", code);
		List<Book> resultList = (List<Book>) typedQuery.getResultList();
		for (Book book : resultList) {
			System.out.println(book.getTitle()+" "+ book.getCost());
			
		}
		return null;
		
	}

	@Override
	public List<Book> getAllBook() {
		TypedQuery<Book> typedQuery= (TypedQuery<Book>) entityManager.createNamedQuery("get_all_books");
		List<Book> resultList = (List<Book>) typedQuery.getResultList();
		for (Book book : resultList) {
			System.out.println(book.getTitle()+" "+ book.getCost()+" "+book.getAuthor()+" "+book.getNoPages());
		}
		return null;
	}
	

}
