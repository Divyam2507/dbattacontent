package com.cg.jpaquerydemo.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;

@Entity
@NamedQueries({
	@NamedQuery(name = "get_by_author_name", query = "select b from Book b where b.author=:author"),
	@NamedQuery(name = "get_by_code", query = "select b from Book b where b.code=:code"),
	@NamedQuery(name = "get_all_books", query = "select b from Book b"),
	
})
public class Book {
	@Id
	private String title;
	private String author;
	private Integer noPages;
	private Integer cost;
	private Integer code;
	public Integer getCode() {
		return code;
	}
	public void setCode(Integer code) {
		this.code = code;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public Integer getNoPages() {
		return noPages;
	}
	public void setNoPages(Integer noPages) {
		this.noPages = noPages;
	}
	public Integer getCost() {
		return cost;
	}
	public void setCost(Integer cost) {
		this.cost = cost;
	}
	
	public Book(String title, String author, Integer noPages, Integer cost, Integer code) {
		super();
		this.title = title;
		this.author = author;
		this.noPages = noPages;
		this.cost = cost;
		this.code = code;
	}
	public Book() {
		super();
	}

}
