package com.cg.jpaquerydemo.ui;

import java.util.Scanner;

import com.cg.jpaquerydemo.dao.bookDaoImpl;
import com.cg.jpaquerydemo.model.Book;
import com.cg.jpaquerydemo.service.bookServiceImpl;

public class User {
	public static void main(String[] args) {
		bookDaoImpl bookserviceimpl = new bookDaoImpl();
		Book book = new Book();
		
//		book.setTitle("e");
//		book.setAuthor("karan");
//		book.setCost(450);
//		book.setNoPages(560);
//		book.setCode(5555);
//		
//		bookserviceimpl.addBook(book);
//		System.out.println(book.getTitle()+" " +book.getAuthor()+ " "+ book.getCost()+ " "+ book.getNoPages()+" "+ book.getCode());
//		
		Scanner sc = new Scanner(System.in);
		
		System.out.println(" enter  author: ");
		String author = sc.next();
		bookserviceimpl.getBookByAuthor(author);
		
		System.out.println(" enter  code of the book: ");
		Integer code = sc.nextInt();
		bookserviceimpl.getBookByCode(code);
		
		bookserviceimpl.getAllBook();
	}

}
