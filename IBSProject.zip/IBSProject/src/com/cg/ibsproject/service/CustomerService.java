package com.cg.ibsproject.service;
import java.util.List;

import com.cg.ibsproject.bean.Document;
import com.cg.ibsproject.bean.LoanMaster;

public interface CustomerService {
	public Loan applyLoan();
	public Loan calculateEmi(Loan loan);

	public Document getDocument();

	public boolean applyPreClosure(long loanNumber);

	public LoanMaster payEMI(long loanNumber);

	public List<LoanMaster> getHistory(String userId);

	public boolean loanCustomerInputVerificationService(Loan loan);

}

