package com.cg.ibsproject.service;
import com.cg.ibsproject.bean.CustomerBean;
import com.cg.ibsproject.bean.Document;
import com.cg.ibsproject.bean.LoanMaster;
import com.cg.ibsproject.dao.BankDao;
import com.cg.ibsproject.dao.BankDaoImpl;

public class BankServiceImpl implements BankService {
	BankDao bankDao = new BankDaoImpl();

	public boolean verifyLoan(CustomerBean customer, Loan loan, Document document) {
		// TODO Auto-generated method stub
		return false;
	}

	public LoanMaster approveLoan(CustomerBean customer, Loan loan, Document document) {
		// TODO Auto-generated method stub
		return null;
	}

	public boolean verifyPreClosure(long loanNumber) {
		// TODO Auto-generated method stub
		return false;
	}

	public LoanMaster approvePreClosure(LoanMaster loanMaster) {
		// TODO Auto-generated method stub
		return null;
	}
	
}
