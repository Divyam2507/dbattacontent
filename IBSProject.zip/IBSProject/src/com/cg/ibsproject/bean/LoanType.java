package com.cg.ibsproject.bean;

public enum LoanType {
	HOME_LOAN, EDUCATION_LOAN, PERSONAL_LOAN, VEHICLE_LOAN

}