package com.cg.ibsproject.ui;
public enum CustomerOptions {

	APPLY_LOAN, PAY_EMI, APPLY_PRECLOSURE, VIEW_HISTORY, EXIT

}