package com.cg.ibsproject.ui;

public enum LoanTypes {
	HOME_LOAN,EDUCATION_LOAN,PERSONAL_LOAN,VEHICLE_LOAN,EXIT, GO_BACK;

}
