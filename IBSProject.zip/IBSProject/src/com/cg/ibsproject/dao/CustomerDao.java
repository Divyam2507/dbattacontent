package com.cg.ibsproject.dao;
import java.util.List;

import com.cg.ibsproject.bean.Document;
//import com.cg.ibsproject.bean.LoanDetails;
import com.cg.ibsproject.bean.LoanMaster;

public interface CustomerDao {
	
	public boolean updateEMI(LoanMaster loanMaster);
	public List<LoanMaster> getHistory(String userId);

}