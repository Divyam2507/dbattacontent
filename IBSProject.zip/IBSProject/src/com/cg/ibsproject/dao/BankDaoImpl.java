package com.cg.ibsproject.dao;
import com.cg.ibsproject.bean.LoanMaster;

public class BankDaoImpl implements BankDao {

	@Override
	public boolean saveLoan(LoanMaster loanMaster) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean savePreClosure(LoanMaster loanMaster) {
		// TODO Auto-generated method stub
		return false;
	}

}
