package com.cg.ibsproject.dao;

import com.cg.ibsproject.bean.LoanMaster;

public interface BankDao {
	public boolean saveLoan(LoanMaster loanMaster);
	public boolean savePreClosure(LoanMaster loanMaster);

}
