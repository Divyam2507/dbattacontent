package com.cg.ibsproject.dao;

import java.util.List;

import com.cg.ibsproject.bean.LoanMaster;

public class CustomerDaoImpl implements CustomerDao {

	@Override
	public boolean updateEMI(LoanMaster loanMaster) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<LoanMaster> getHistory(String userId) {
		// TODO Auto-generated method stub
		return null;
	}
}
/*
 package com.cg.ibsproject.dao;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;
import java.awt.List;
import java.math.BigDecimal;

import com.cg.ibsproject.bean.CustomerBean;
import com.cg.ibsproject.bean.LoanDetails;
import com.cg.ibsproject.bean.LoanMaster;

public class CustomerDaoImpl implements CustomerDao {
	CustomerBean customerBean = new CustomerBean();
	customerBean.set();
  
	
	private static Map<String, LoanMaster> loanMasterDetails = new HashMap<String, LoanMaster>();
	
	
	
	LoanMaster loanMaster =  new LoanMaster(2500000.00,120,new BigDecimal("30996"),customerBean, 120, 60, LocalDate.now());
	LoanMaster loanMaster1 = new LoanMaster(1000000.00,24,new BigDecimal("45800"),customerBean, 24, 16, LocalDate.now());
	LoanMaster loanMaster2 = new LoanMaster(500000.00,24,new BigDecimal("23583"),customerBean, 24, 23, LocalDate.now());
	LoanMaster loanMaster3 = new LoanMaster(1000000.00,60,new BigDecimal("46771"),customerBean, 60, 50, LocalDate.now());
	
	LoanMaster loanMastern = new LoanMaster(loanMaster.getLoanAmount(),loanMaster.getLoanTenure(),loanMaster.getEmiAmount(),loanMaster.getCustomerBean(),loanMaster.getNumberOfEmis(),loanMaster.getTotalNumberOfEmis(),loanMaster.getLoanApplyDate());
	@Override
	public boolean updateEMI(LoanMaster loanMaster) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List getHistory(String userId) {
		// TODO Auto-generated method stub
		return null;
	}
	

}


 */
 